package online.dwResources;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import online.configuration.TopTrumpsJSONConfiguration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

// Import the command line package
import commandline.*;

@Path("/toptrumps") // Resources specified here should be hosted at http://localhost:7777/toptrumps
@Produces(MediaType.APPLICATION_JSON) // This resource returns JSON content
@Consumes(MediaType.APPLICATION_JSON) // This resource can take JSON content as input
/**
 * This is a Dropwizard Resource that specifies what to provide when a user
 * requests a particular URL. In this case, the URLs are associated to the
 * different REST API methods that you will need to expose the game commands
 * to the Web page.
 * 
 * Below are provided some sample methods that illustrate how to create
 * REST API methods in Dropwizard. You will need to replace these with
 * methods that allow a TopTrumps game to be controled from a Web page.
 */
public class TopTrumpsRESTAPI {
	
	/** A Jackson Object writer. It allows us to turn Java objects
	 * into JSON strings easily. */
	ObjectWriter oWriter = new ObjectMapper().writerWithDefaultPrettyPrinter();
	Game game;	// Game object
	String deckFile; // Deck filenames
	private int humansChoice; // What category did the human choose 
	private String roundResult; // Result of a round
	private String gameResult;	// Result of a game
	// Need to store the previous card data as after a win, the cards are stripped
	// from each players' hands
	String [][] allCardData;
	
	/**
	 * REST API Constructor
	 * @param conf
	 */
	public TopTrumpsRESTAPI(TopTrumpsJSONConfiguration conf) {
		
		deckFile = conf.getDeckFile(); // Deck file name
		humansChoice = -1; // set sentinel for human's choice

	}
		
	@GET
	@Path("/initGame")

	/**
	 * Initiate the game
	 * @param noOfPlayers
	 * @return the first player
	 * @throws IOException
	 */
	public int initGame(@QueryParam("noOfPlayers") int noOfPlayers)  throws IOException {
		
		game = new commandline.Game(); // Utilise command line core
		game.setDeckFile(deckFile); // Set deck file in Game objects
		game.initMainDeck(); // Initiate main deck
		game.shuffleDeck(); // Shuffle deck
		game.initPlayers(noOfPlayers); // Initiate the number of players
		game.dealCards(); // Deal cards
		
		int firstPlayer = game.getFirstPlayer(); // Who goes first
		game.setTurn(firstPlayer); // Set turn to this player
		
		return firstPlayer;
		
	}

	@GET
	@Path("/getCardData")
	/**
	 * Get the card data
	 * This gets the fresh cards after a win
	 * @return - Multi-dimensional array of card data
	 * @throws IOException
	 */
	public String getCardData() throws IOException {
		
		String [][] allCardData = game.getCardData();
		String listAsJSONString = oWriter.writeValueAsString(allCardData);
		return listAsJSONString;
	
	}
	
	@GET
	@Path("/getCardDataStored")
	/**
	 * Get the card data
	 * This gets the stored card data as cards will be stripped of
	 * each player's decks after a hand
	 * @return - Multi-dimensional array of card data
	 * @throws IOException
	 */
	public String getCardDataStored() throws IOException {
		
		String listAsJSONString = oWriter.writeValueAsString(allCardData);
		return listAsJSONString;
	
	}	
	
	
	@GET
	@Path("/getCategory")
	/**
	 * Get the category in play
	 * @return Category as a string
	 * @throws IOException
	 */
	public String getCategory() throws IOException {

		return "" + game.getCategory();
		
	}
	
	@GET
	@Path("/getCategories")
	/**
	 * Get the category headings
	 * @return category headings
	 * @throws IOException
	 */
	public String getCategories() throws IOException {
		
		String [] categories = game.getCategories();
		String listAsJSONString = oWriter.writeValueAsString(categories);
		
		return listAsJSONString;
	}	
	
	@GET
	@Path("/getPlayersDeckCount")
	/**
	 * Get the deck counts for each player
	 * @return count of each player's deck
	 * @throws IOException
	 */
	public String getPlayersDeckCount() throws IOException {
		
		String [] deckCount = game.getPlayersDeckCount();
		String listAsJSONString = oWriter.writeValueAsString(deckCount);
		
		return listAsJSONString;
	}	
	
	@GET
	@Path("/getCatSelect")
	/**
	 * Get category select options
	 * @return inner html for human category select
	 * @throws IOException
	 */
	public String getCatSelect() throws IOException {
		
		StringBuilder select = new StringBuilder();
		String [] categories = game.getCategories();
		select.append("<option value=-1>-- choose category</option>");
		for(int i = 0; i < categories.length; i++) {
			select.append("<option value=" + i + ">" + categories[i] + "</option>");
		}
		
		return select.toString();
		
	}
	
	@GET
	@Path("/playRound")
	/**
	 * Advances the game through one round of play
	 * @return int indicator of whether the game is over or not
	 * */
	public int playRound() {
			
		game.updateRounds(); // Add 1 to rounds played

		if(game.getPlayerType() == "HUMAN")	{ 	
			
			game.setCategory(humansChoice); 
			
		} else if(game.getPlayerType() == "COMPUTER") {
			
			game.setCategory(game.getNextCard().getBestCategory()); 
			
		}

		// Keep a record of the card data as once there is a win,
		// the card data will need to be displayed for reference
		allCardData = game.getCardData();
	
		if(game.isDraw()) 
		{ 
			roundResult = "The round was a draw";
			game.addCardsToCommunalDeck(); // Add all top cards to communal deck
			game.updateDraws(); // Add 1 to draw count

		} else  {

			int roundWinner = game.getWinner() + 1;	
			roundResult = "Winner of the round is player: " + roundWinner;
			game.setTurn(game.getWinner()); // Set turn
			game.updateWins(); // Update current player's score
			game.addCardsToWinner();// Winner gets losers' top cards and communal deck		
			
		}	

		// Always reset HUMAN's choice so that it the value
		humansChoice = -1;
		
		// we check if the game is over here, at the end of every round	
		if (game.isStalemate()) 
		{ 		
			// Stalemate - Don't do anything about it though
			gameResult = "The game was a stalemate";
			return 2;	
			
		} else if (game.isGameOver()) 	{ 	
			
			// Winner of the game message
			gameResult = "Winner of the game is player " + (game.getTurn() + 1);
			game.saveStats(); // Save the game stats to database
			return 1;
				
		} else	{
			
			return 0;
			
		}
			
	}	

	@GET
	@Path("/setHumanCategory")
	/**
	 * Sets the Players category
	 * @param input - The category (Number) the human player chose
	 */
	public void setHumanCategory(@QueryParam("humanCategory") int humanCategory) throws IOException {

		this.humansChoice = humanCategory;
		
	}
	
	@GET
	@Path("/getTurn")
	/**
	 * Get the next turn
	 * @return the next player
	 */
	public int getTurn() throws IOException {

		return game.getTurn();
	
	}
	
	@GET
	@Path("/getCommunalDeckCount")
	/**
	 * Get the communal deck
	 * @return the communal deck
	 */
	public int getCommunalDeckCount() throws IOException {

		return game.countCardsInCommunalDeck();
	
	}
	
	@GET
	@Path("/validateRound")
	/**
	 * Check if it is the HUMAN's turn and whether they have 
	 * selected a category or not
	 * @return 0 or 1
	 */
	public int validateRound() {
		
		int isValid = 1;
		
		 // Human has NOT select a category yet
		if(game.getTurn() == 0 && humansChoice == -1) {
			isValid = 0;
		} 

		return isValid;
		
	}
	
	@GET
	@Path("/getRoundResult")
	/**
	 * @return - String representing the status of the round
	 */
	public String getRoundResult() {
		
		return roundResult;
		
	}
	
	@GET
	@Path("/getGameResult")
	/**
	 * Get the game result when a player has won
	 * @return - String with the game result
	 */
	public String getGameResult() {
		
		return gameResult;
		
	}
	
	@GET
	@Path("/getStats")
	/**
	 * Get the game stats
	 * @return json string of previous game stats
	 * @throws IOException
	 */
	public String getStats() throws IOException {
		
		// Game object needs instantiated here 
		// as the user may not proceed to a Game proper
		game = new commandline.Game();
		// get game stats from db
		double [] stats = game.getStats();
		// Convert to Json
		String listAsJSONString = oWriter.writeValueAsString(stats);
		game = null;
		
		return listAsJSONString;
	}
	
}