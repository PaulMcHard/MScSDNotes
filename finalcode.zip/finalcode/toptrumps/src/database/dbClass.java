package database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * dbClass
 * =======
 * Database connector
 * 
 * @author Team 12 - Paul McHard, Lewis Renfrew, Nick Ferrara, Kayleigh Chisholm & Eoghan Malone
 *
 */
public class dbClass {

	private Connection connection = null;
	private String dbname, username, password;
	
	// Constructor
	public dbClass(String db, String un, String pw) {
		
		dbname = db; 
		username = un;
		password = pw;

		dbConnect(); // Connect to database
	}
	
	/**
	 * Connect to database
	 */
	private void dbConnect() {
		
		try {
			
			connection = DriverManager.getConnection("jdbc:postgresql://yacata.dcs.gla.ac.uk:5432/" +  dbname, username, password);
		}
		
		catch (SQLException e) {}
		
	}
	
	/**
	 *  Close connection
	 */
	public void dbCloseConnection() {
		
		try {
			
			connection.close();

		}
		
		catch (SQLException e){
		
		}
	}	
	

	/**
	 * Execute query
	 * @param sql
	 * @return resultset rs
	 */
	public ResultSet executeQuery(String sql) {
		
		Statement stmt = null;
		String query = sql;
		ResultSet rs = null;
		
		try {
			
			stmt = connection.createStatement();
			rs = stmt.executeQuery(query);
			
		}
		
		catch (SQLException e) {}
		
		return rs;
		
	}
			
}
