package commandline;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
import java.sql.ResultSet;
import java.sql.SQLException;

// Database class
import database.dbClass;

/**
 * Game - Facade class
 * ===================
 *
 * Manages the heavy lifting and contains game logic
 * Exposes the logic of all other classes and provides a simple interface
 * for both the command line and online top trumps games
 * 
 * @author Team 12 - Paul McHard, Lewis Renfrew, Nick Ferrara, Kayleigh Chisholm & Eoghan Malone
 * 
 */
public class Game {
	
	// Deck file
	private String fileDeck;
	
	// Game objects
	private Deck deckMain; // Main deck
	private Deck deckCommunal; // Communal deck
	private Player [] objPlayers; // Array of player objects
	
	// Logging
	private Log log; 
	private boolean isLogging = false;
	
	// Game constants
	private final int MAX_CATEGORIES = 5; // Max no of categories
	private final int MIN_CATEGORIES = 1; // Min no of categories
	private final int MAX_CARDS = 40; // Number of cards in deck
	private final int MAX_STATS_COLS = 5; // Columns for stats
	private final String textPlayGame = "play"; // Play text
	private final String textStats = "stats"; // Stats text
	private final String textQuit = "quit"; // Quit text
	
	// Array of categories
	private String [] deckCategories; // Size, Speed, Range, Firepower, Cargo, etc.
	
	// Track gameplay
	private int turn; // Track who's turn it is
	private int category; // Category chosen by HUMAN or COMPUTER player
	private int draws; // Count the number of draws
	private int rounds; // Count the number of rounds
	
	// Database
	dbClass db;

	//private final String dbName = "toptrumps";
	//private final String dbUser = "postgres";
	//private final String dbPass = "eoghan";
	
	private final String dbName = "m_17_2084132r";
	private final String dbUser = "m_17_2084132r";
	private final String dbPass = "2084132r";
	
	/**
	 * Constructor
	 */
	public Game() {
		
		deckMain = new Deck(MAX_CARDS); // Dimension main deck
		deckCommunal = new Deck(MAX_CARDS); // Dimension communal deck
				
	}
	
	/**
	 * Load in the deck from file
	 */
	public void initMainDeck() {
				
		try {
			
			FileReader reader = new FileReader(fileDeck);
			Scanner sc = new Scanner(reader);

			String line = sc.nextLine();
			setCategories(line);

			while (sc.hasNextLine()) {

				line = sc.nextLine();

				// Create a Card object
				Card card = new Card(line, MAX_CATEGORIES);

				// insert card into deck
				deckMain.addCardToDeck(card);
			}
			sc.close();
			reader.close();

		} catch(IOException e) {}

	}
	
	/**
	 * Initiate the players
	 * @param noOfPlayers
	 */
	public void initPlayers(int noOfPlayers) {
		
		// Dimension the players array
		objPlayers = new Player[noOfPlayers];
		
		for(int i = 0; i < objPlayers.length; i++) {
		
			// Create each player
			Player player = new Player(MAX_CARDS);
			objPlayers[i] = player;
			
			if(i == 0) { // HUMAN [there will always be 1 human, so use first index]
			
				objPlayers[i].setPlayerType("HUMAN");
			
			} else { // COMPUTER [All other players are human]
	
				objPlayers[i].setPlayerType("COMPUTER");
	
			}
	
		}
		
	}

	/**
	 * Shuffle deck
	 */
	public void shuffleDeck() {
		
		this.deckMain.shuffleDeck();
		
	}

	/**
	 * Get main deck
	 * @return main deck
	 */
	public Deck getMainDeck() {
		
		return this.deckMain;
	}
	
	/**
	 * Deal the cards out to the players
	 */
	public void dealCards() {
		
		// Track player in deal
		int playerCounter = 0;
		
		for(int i = 0; i < MAX_CARDS; i++) {
			
			// Add this card to the player ith's hand
			objPlayers[playerCounter].addCardToDeck(deckMain.getCardByIndex(i));
	
			playerCounter++;
			if(playerCounter == objPlayers.length) { playerCounter = 0;}
				
		}
		
	}

	/**
	 * Get communal deck
	 * @return communal deck
	 */
	public Deck getCommunalDeck() {
		
		return this.deckCommunal;
		
	}
	
	/**
	 * Set log object
	 * @param log object
	 */
	public void setLog(Log log) {
		
		this.log = log;
		
	}

	/**
	 * Set deck file
	 */
	public void setDeckFile(String file) {
		this.fileDeck = file;
	}

	/**
	 * Set the categories
	 */
	public void setCategories(String catParams) {
		
		String [] arrayData = catParams.split(" "); // split line by spaces		
		deckCategories = new String [MAX_CATEGORIES];
	
		for(int i = 0; i < MAX_CATEGORIES; i++) {
			
			deckCategories[i] = arrayData[i+1]; // skip first column [description]
				
		}
		
	}
	
	/**
	 * Get categories [online]
	 * @return array of category headings
	 */
	public String[] getCategories() {
		
		return deckCategories;
	}

	/**
	 * Set category
	 * @param category
	 */
	public void setCategory(int category) {
		
		this.category = category;
		
	}

	/**
	 * Set turn
	 * @param turn
	 */
	public void setTurn(int turn) {
		
		this.turn = turn;
		
	}

	/**
	 * Check if integer
	 * Nice and neat
	 * @param input
	 * @return integer or error flag
	 */
	private int checkInt(String input) {
		
		try {
			
			return Integer.parseInt(input);
			
		} catch(NumberFormatException e) {
			
			return -1;
		}
	}
	
	/**
	 * Check that the category selected by the human is in range
	 * @param string 
	 * @return true or false
	 */
	public boolean validateCategory(String input) {
		
		if(input.length() != 1 || checkInt(input) == -1) {
			return false;
		}
		
		if(Integer.parseInt(input) < MIN_CATEGORIES || Integer.parseInt(input) > MAX_CATEGORIES) {
			return false;
		}
	
		return true;
		
	}

	/**
	 * Main menu options. 
	 * Returns a sentinel value or calls itself if invalid
	 * @return a sentinel value
	 */
	public int getGameOptions() {
		
		System.out.println("\nEnter 'play' to start game, 'stats' to see stats, or 'quit' to quit\n");
		Scanner scan = new Scanner(System.in);
		String input = scan.nextLine();
		input = input.toLowerCase();
		
		if(input.trim().equals(textQuit)) { // user can break out now if they want
			
			return -1; // quit sentinel
			
		} else if (input.trim().equals(textPlayGame)) {
			
			return 1; // play game
		
		} else if  (input.trim().equals(textStats)){
			
			return 2; // stats
			
		} else { // input not recognised

			System.out.println("\nOption not recognised. Please try again.\n");
			return getGameOptions();
			
		}
		
	}
	
	/**
	 * Get turn
	 * @return int
	 */
	public int getTurn() {
		
		return this.turn;
		
	}

	/**
	 * Get the category from the HUMAN
	 * Recursive call
	 * Returns int when parameters are fully satisfied
	 * @return -1 or 1
	 */
	public int getHumanCategory() {
		
		System.out.println("Select a category [" + MIN_CATEGORIES  + " to " + MAX_CATEGORIES + "] or type 'quit' to exit.");
		Scanner scan = new Scanner(System.in);
		String input = scan.nextLine();
	
		if(input.toLowerCase().trim().equals(textQuit.toLowerCase())) { // user can break out now if they want
					
			return -1; // quit sentinel
	
		} else {
					
			if(!validateCategory(input)) { // check valid category
	
				System.out.println("\nNot a valid category. Enter a value in the range of 1 to 5. Please try again.\n");
				return getHumanCategory();
				
			} else {
				
				// Numeric, and in correct range
				category = Integer.parseInt(input) - 1; // correct for 0 index
				return 1;
				
			}
						
		}
		
	}

	/**
	 * Who goes first
	 * @return first player
	 */
	public int getFirstPlayer() {
		
		Random random = new Random();
		return random.nextInt(objPlayers.length);
		
	}

	/** 
	 * Get the top card
	 * @return Card
	 */
	public Card getNextCard() {
		
		return this.objPlayers[turn].getTopCard();
		
	}

	
	/**
	 * Count cards in a players deck
	 * [utilised for online game]
	 * @return Count of cards in each players' deck
	 */
	public String [] getPlayersDeckCount() {
		
		// Array of player scores
		String [] deckCount = new String[objPlayers.length];
		
		for(int i=0; i < objPlayers.length; i++) {
			
			deckCount[i] = "" + objPlayers[i].countCardsInDeck(); // convert to string
				
		}
	
		return deckCount;
	}
	
	/**
	 * Get raw card data
	 * [utilised for online game]
	 * @return all card data
	 */
	public String [][] getCardData() {
		
		String [][] allCardData = new String[objPlayers.length][MAX_CATEGORIES+1];
		
		for(int i=0; i < objPlayers.length; i++) {
			
			if(objPlayers[i].countCardsInDeck() != 0) { // Skip players with no cards in deck
	
				Card card = objPlayers[i].getTopCard();
				allCardData[i][0] = card.getCardDescription();
				int [] cardValues = card.getCardValues();
				
				for(int j = 0; j < MAX_CATEGORIES; j++) {
					
					allCardData[i][j+1] = "" + cardValues[j];
					
				}
			}
			
		}
	
		return allCardData;
	}

	/**
	 * Get player type
	 * @return string
	 */
	public String getPlayerType() {
		
		return objPlayers[getTurn()].getPlayerType();
		
	}

	/**
	 * Get the winner
	 * Just need the max value in array
	 * Called on demand.
	 * NOTE: must be called before cards are stripped from losers
	 * as it takes values of the current top cards
	 * [getRoundWinner() is used for the for the final win]
	 * @param values
	 * @return integer value of winner
	 */
	public int getWinner() {
		
		int [] playerScores = playerCardValues();
		
		int winner = -1;  
		int maxValue = 0;
	
		for(int i = 0; i < playerScores.length; i++) {
		
			if(playerScores[i] > maxValue) {
				maxValue = playerScores[i];
				winner = i;
			}
			
		}
		
		return winner;
		
	}

	/**
	 * Count players
	 * @return number of players
	 */
	public int getCountPlayers() {
		
		return this.objPlayers.length;
		
	}
	
	/**
	 * Count cards in main deck
	 * @return number of cards in deck
	 */
	public int countCardsInMainDeck() {

		return this.deckMain.countCardsInDeck();
		
	}
	
	/**
	 * Count cards in communal
	 * @return number of cards in deck
	 */
	public int countCardsInCommunalDeck() {

		return this.deckCommunal.countCardsInDeck();
		
	}

	/**
	 * Prints the contents of a users top card to console or log
	 * @param player          which players card should be displayed
	 * @param printToConsole  whether or not the card should be printed to console 
	 */
	public void displayCard(int player, boolean printToConsole) {
		
		Card card = objPlayers[player].getTopCard();
		
		StringBuilder catnumbers = new StringBuilder(); // cat numbers
		catnumbers.append(String.format("%-20s",""));
		for(int i = 0; i < MAX_CATEGORIES; i++) {
			catnumbers.append(String.format("%-12s","#" + (i+1)));

		}
		
		StringBuilder headings = new StringBuilder(); // headings
		headings.append(String.format("%-20s","Description"));
		for(int i = 0; i < MAX_CATEGORIES; i++) {
			headings.append(String.format("%-12s",deckCategories[i]));

		}
		
		StringBuilder rows = new StringBuilder(); // description values
		rows.append(String.format("%-20s",card.getCardDescription())); // i.e. Avenger, Vanguard, etc.
		int [] values = card.getCardValues();
		for(int i = 0; i < values.length; i++) {
			rows.append(String.format("%-12s",values[i]));
		}
		
		rows.append("\n");

		if(printToConsole) { // Output strings to console
			
			System.out.println(catnumbers);
			System.out.println(headings);
			System.out.println(rows);
			
		} else if(isLogging) { // write to log file
			
			log.write(catnumbers.toString(), true);
			log.write(headings.toString(), true);
			log.write(rows.toString(), true);
			
		}
		
	}
	
	/**
	 * Display the values of the players' cards
	 */
	public void displayPlayerScores() {
		
		System.out.println("Players' values for this category:\n");
		
		int [] playerScores = playerCardValues();
		for(int i = 0; i < playerScores.length; i++) {		
			
			System.out.print("Player " + formatTextPlayerNumber(i) +  ": ");
			
			if(playerScores[i] == -1) { // knocked out
			
				System.out.print("KNOCKED OUT");
				
			} else { // display player's value
				
				System.out.print(playerScores[i]);
			}
				
			System.out.println();
		}
		
	}
	
	/**
	 * Display the winner
	 */
	public void displayWinner() {
		
		System.out.println("Winner of the game is player #" + formatTextPlayerNumber(turn));

	}
	
	/**
	 * Display the winner
	 */
	public void displayRoundWinner() {
		
		System.out.println("\nWinner of round is player #" + formatTextPlayerNumber(getWinner()));
		System.out.println();
		System.out.println("Winning card is:\n");
	}
	
	/**
	 * Draw
	 */
	public void displayDraw() {
		System.out.println();
		System.out.println("Draw");
	}
	
	
	/**
	 * Get the current category
	 * [used for online]
	 */
	public String getCategory() {
		
		return deckCategories[category];
		
	}
	
	/**
	 * Display category selected
	 */
	public void displayCatSelected() {
		
		System.out.println("\nCategory selected by " + objPlayers[turn].getPlayerType().toLowerCase() + ": " + deckCategories[category] + "\n");

	}
	
	/**
	 * Display the stats to the commandline
	 */
	public void displayStats() {
		
		double [] stats = getStats();
		String [] statsHeadings = {"Overall Games","Human Wins", "Computer Wins","Avg. Draws","Max Rounds in 1 game"};
		
		// cat numbers
		StringBuilder statsHeaders = new StringBuilder();
		StringBuilder statsData = new StringBuilder();
		
		for(int i = 0; i < MAX_STATS_COLS; i++) {
			statsHeaders.append(String.format("%-18s",statsHeadings[i]));
			if(i==3) { // average draws 
				statsData.append(String.format("%-18s",stats[i])); // keep precision for avg draws
			} else { // everything else is ints
				statsData.append(String.format("%-18s",(int)stats[i])); // kill precision
			}
		}
		
		// Display stats to command line
		System.out.println("\nPrevious game stats:\n");
		System.out.println(statsHeaders);
		System.out.println(statsData);
		System.out.println("");
		
	}
	
	/**
	 * Display current player
	 */
	public void displayCurrentPlayer() {
		
		System.out.println("Current Player #" + formatTextPlayerNumber(getTurn()) + " [" + getPlayerType() + "]\n");
		System.out.println("Top card for this player:\n");

	}
	
	/**
	 * Display round
	 */
	public void displayRound() {
		
		System.out.println("\nRound: " + rounds + "\n");
		
	}
	
	/**
	 * Get card values [face values] of each of the players' cards
	 * @return an array of scores as integers
	 */
	public int [] playerCardValues() {

		int [] playersCardValues = new int[objPlayers.length];
		
		for(int i = 0; i < objPlayers.length; i++) {
			
			playersCardValues[i] = -1; // set initial score to -1 for each player
			
			// Skip players with no cards in their hand, they all have scores of -1 and can never win/draw
			if(objPlayers[i].countCardsInDeck() != 0) {
			
				// get the values of this player's card i.e. cats 1 to 5
				int [] values = objPlayers[i].getTopCard().getCardValues();
				playersCardValues[i] = values[category]; // add score to tracker
				
			}
			
		}
		
		return playersCardValues;

	}
	
	/**
	 * Max value in array
	 * @return the maximum value of an array
	 */
	public int maxValueOfArray(int [] values) {

		int maxValue = 0;  

		for(int i = 0; i < values.length; i++) {
		
			if(values[i] > maxValue) {
				maxValue = values[i];
			}
			
		}
		
		return maxValue;
	}
	
	/**
	 * Check if it is a draw
	 * Checks the values of non-knocked out players and current player
	 * @param values
	 * @return true or false
	 */
	public boolean isDraw() {
		
		int [] playerScores = playerCardValues();
		boolean isDraw = false;
		int bestScore = -1; // track best score
		
		for(int i = 0; i < playerScores.length; i++) {
			
			// Skip current player [turn] and knocked out players [card value = -1]
			if(i != turn && playerScores[i] != -1) { 
				
				if(playerScores[i] > bestScore) {
					bestScore = playerScores[i]; // Track the best score
				}
								
			}
			
		}
		
		// Is the best score the same as the current player?
		if(bestScore == playerScores[turn]) {	
			isDraw = true; // draw					
		}
	
		// Lastly, Check for exception
		// Does another player [other than current player] 
		// have the same score as the best player?
		if(bestScore > playerScores[turn]) {	
			int scoreOccurence = 0; 
			for(int i = 0; i < playerScores.length; i++) {
				if(i != turn && playerScores[i] != -1) { 
					if(playerScores[i] == bestScore) { 
						scoreOccurence++;
					}
				}
			}
			
			if(scoreOccurence>1) { 
				isDraw = true; // treat as a draw [See assumptions]
			}
			
		}
						
		return isDraw;
		
	}
	
	/**
	 * Set logging flag
	 * @param logging
	 */
	public void isLogging(boolean logging) {
		
		this.isLogging = logging;
		
	}

	/**
	 * Is game over?
	 * Does a player have MAX_CARDS
	 * @return
	 */
	public boolean isGameOver() {
		
		boolean gameOver = false;

		for(int i = 0; i < objPlayers.length; i++) {
			
			// If one player has MAX_CARDS cards left, then game is over
			if(objPlayers[i].countCardsInDeck() == MAX_CARDS) { 
				
				gameOver = true; 
				
			}
			
		}
					
		return gameOver;
		
	}
	
	/**
	 * Check for stalemate
	 * Stalemate occurs when there are 40 cards in the communal deck
	 * [we are not explicitly dealing with it, just scanning for the occurrence of the condition]
	 * @return true or false
	 */
	public boolean isStalemate() {
		
		return (deckCommunal.countCardsInDeck() == MAX_CARDS) ? true : false;
	}
	
	/**
	 * Add cards from a draw round to communal deck
	 */
	public void addCardsToCommunalDeck() {
		
		for(int i = 0; i < objPlayers.length; i++) {
			
			// Skip players with no cards in deck
			if(objPlayers[i].countCardsInDeck() != 0) {
				
				// Add the top card of each player to communal pile
				deckCommunal.addCardToDeck(objPlayers[i].getTopCard());

				// Delete card from player's hand. Just NULL top index
				objPlayers[i].deleteTopCard();				

			}
			
		}
		
	}
	
	/**
	 * Add cards from a win round to winner's hand
	 * Takes cards from non-knocked out players and puts the to the BACK of the winner's hand
	 * Takes all the cards from communal deck and puts them to the BACK of the winner's hand
	 * Simplest way to do this is to create a temp deck:
	 * ================================================
	 *  - Add the winners card to the temp deck
	 *  - Add the losers' cards to the temp deck
	 *  - Add the communal deck to the temp deck
	 *  - Lastly, add the current player's hand to the temp deck
	 *  - Set the player's current hand to the new temp deck
	 */
	public void addCardsToWinner() {
		
		int winner = getWinner();
		Deck tempDeck = new Deck(MAX_CARDS);
		
		// take top card and put it in the temp deck
		tempDeck.addCardToDeck(objPlayers[winner].getTopCard());
		objPlayers[winner].deleteTopCard();	// delete the top card
		
		// Take cards off the losers
		for(int i = 0; i < objPlayers.length; i++) {
			
			// Skip winner and players with no cards in deck
			if(objPlayers[i].countCardsInDeck() != 0 && i != winner) {

				// Add the top card of each player to winner's hand
				tempDeck.addCardToDeck(objPlayers[i].getTopCard());
				// Delete card from ith loser's hand. Just NULL top index
				objPlayers[i].deleteTopCard();		
				
			}
			
		}
			
		// Transfer cards from the communal pile into the temp deck
		int countCommunal = deckCommunal.countCardsInDeck();
		if(countCommunal !=0 ) {
			
			for(int i = 0; i < countCommunal; i++) {
				
				tempDeck.addCardToDeck(deckCommunal.getCardByIndex(i)); // Add card to temp deck
							
			}
			
		}
		
		deckCommunal = new Deck(MAX_CARDS); // Reset communal deck
		
		// Transfer current hand to temp deck
		for(int i = 0; i < objPlayers[winner].countCardsInDeck(); i++) {
			
			tempDeck.addCardToDeck(objPlayers[winner].getCardByIndex(i)); // Add card to temp deck
						
		}
		
		// Log the contents of the communal deck to the log file
		logDeckContents("Communal deck contents", deckCommunal);
		
		// set the hand of the ith player to tempDeck
		objPlayers[winner].setPlayerHand(tempDeck,MAX_CARDS);
		
	}
	
	/**
	 * Add 1 to rounds played
	 */
	public void updateRounds() {
		
		this.rounds = rounds + 1;
		
	}
	
	/**
	 * Add 1 to draws played
	 */
	public void updateDraws() {
		
		this.draws = draws + 1;

	}
	
	/**
	 * Update the relevant player object
	 */
	public void updateWins() {
		
		objPlayers[getWinner()].updateWins();
		
	}
	
	/**
	 * Reset the game stats
	 */
	public void resetGameStats() {
		
		this.draws = 0;
		this.rounds = 0;

	}
	
	//-----------------------------------------------------------------
	// Miscellaneous helpers for formatting
	//-----------------------------------------------------------------
	
	/**
	 * Correct 0 indexed players. I.e. 0 is player 1, 1 is player 2,...
	 * @param player
	 * @return
	 */
	public int formatTextPlayerNumber(int player) {
		return player + 1;
	}
		
	/**
	 * Out put text
	 */
	public void outputText(String string) {
		System.out.println(string);
	}
	
	//-----------------------------------------------------------------
	// Database helpers
	//-----------------------------------------------------------------
	
	/**
	 * Save stats to database
	 */
	public void saveStats() {

		db = new dbClass(dbName, dbUser, dbPass);
		db.executeQuery("INSERT INTO game (draws, rounds, winnerid) VALUES("+this.draws+","+this.rounds+","+formatTextPlayerNumber(turn)+")");
		int gameID = 0;
		try {
			ResultSet gID = db.executeQuery("SELECT MAX(gameid) FROM game");
			gID.next();
			gameID = gID.getInt(1);
			
			for(int i = 0; i < objPlayers.length; i++) {
				db.executeQuery("INSERT INTO playerdata (gameid, playerid, wins) VALUES ("+gameID+","+formatTextPlayerNumber(i)+","+objPlayers[i].getWins()+")");
			}
		}
		catch (SQLException e) {}
		
		db.dbCloseConnection();

	}
	
	/**
	 * Get persistent data
	 * @return an array of game stats
	 */
	public double [] getStats() {
		
		double [] stats = new double[MAX_STATS_COLS];
		db = new dbClass(dbName, dbUser, dbPass);
		
		String sql = "SELECT " + 
					 "(SELECT COUNT(g.gameid) FROM game g ) AS totalGamesPlayed, " + 
					 "(SELECT COUNT(g.gameid) FROM game g WHERE g.winnerid = 1) AS totalHumanWins, " + 
					 "(SELECT COUNT(g.gameid) FROM game g WHERE g.winnerid > 1) AS totalCompWins, " + 
					 "(SELECT ROUND(AVG(g.draws),2) FROM game g) AS avgDraws, " + 
					 "(SELECT MAX(g.rounds) FROM game g) AS maxRoundsPlayed " + 
					 "FROM game " + 
					 "LIMIT 1";
		
		try {
			
			ResultSet rs = db.executeQuery(sql);
			while(rs.next()) {
				for(int i = 0; i < MAX_STATS_COLS; i++) {
						stats[i] = rs.getDouble(i+1);

				}
			}

		}
		catch (SQLException e) {}
		db.dbCloseConnection();
		
		return stats;
	
	}
	
	//-----------------------------------------------------------------
	// Logging helpers
	//-----------------------------------------------------------------
	
	/**
	 * Log the contents of a given deck
	 * 
	 * @param header  heading to explain which deck contents are being logged (e.g initial, shuffled, communal etc.)
	 * @param deck
	 */
	public void logDeckContents(String header, Deck deck) {

		if (isLogging) {
			log.write("--------------------------------------------------------------------------", true);
			log.write(header + " Deck Contents", true);
			log.write("--------------------------------------------------------------------------", true);
			log.write(String.format("%-20s", "Description"), false);
			
			for (int i = 0; i < deckCategories.length; i++) {

				log.write(String.format("%-12s", deckCategories[i]), false);
				if (i == deckCategories.length - 1) {
					log.write("", true);
				}
			}
			for (int j = 0; j < deck.countCardsInDeck(); j++) {

				Card card = deck.getCardByIndex(j);
				
				log.write(String.format("%-20s", card.getCardDescription()), false);
				int[] values = card.getCardValues();
				for (int k = 0; k < values.length; k++) {
					log.write(String.format("%-12s", values[k]), false);
				}
				log.write("", true);
			}
			log.write("", true);
		}
	}
	
	/**
	 * Log player contents
	 */
	public void logPlayerDeckContents() {
				
		for(int i = 0; i < objPlayers.length; i++) {

			logDeckContents("Player #" + formatTextPlayerNumber(i) + " [" + objPlayers[i].getPlayerType() + "]", objPlayers[i].getDeck());
			
		}
			
	}	
	
	/**
	 * Log each players' top card
	 */
	public void logCardsInPlay() {
		
		if (isLogging) {
			
			for (int i = 0; i < (objPlayers.length); i++) {
				
				if(objPlayers[i].countCardsInDeck() != 0) {
					
					log.write("--------------------------------------------------------------------------", true);
					log.write("Player #" + formatTextPlayerNumber(i) + " Top Card", true);
					log.write("--------------------------------------------------------------------------", true);
					displayCard(i, false);
				}
			}
		}
	}
	
	/**
	 * Log category [fires the logCorrespondingValues methods to keep in line with spec]
	 */
	public void logCategory() {
		
		if(this.isLogging) {

				log.write("--------------------------------------------------------------------------", true);
				log.write("Chosen Category and Corresponding Values", true);
				log.write("--------------------------------------------------------------------------", true);
				log.write(getPlayerType() + " player #" + formatTextPlayerNumber(turn) + " chose category: " + deckCategories[category], true);
				log.write("", true);
				logCorrespondingValues(); // spec dictates that both fire together
				
		}
		
	}
	
	/**
	 * Log corresponding values
	 */
	public void logCorrespondingValues() {

		for (int i = 0; i < objPlayers.length; i++) {

			if (objPlayers[i].countCardsInDeck() != 0) { // not knocked out

				int[] playerScores = playerCardValues();
				log.write("player #" + formatTextPlayerNumber(i) + " : " + playerScores[i], true);

			} else { // knocked out

				log.write("player #" + formatTextPlayerNumber(i) + " : KNOCKED OUT", true);

			}
		}

		log.write("", true);

	}
	
	/**
	 * Log the winner of the game
	 */
	public void logWinnerOfGame() {
	
		if (isLogging) {
			log.write("WINNER of game is player #" + formatTextPlayerNumber(turn), true);
			log.write("", true);
		}
	}
	
	/**
	 * Log the winner of the round
	 */
	public void logWinnerOfRound() {
	
		if (isLogging) {
			log.write("WINNER of round is player #" + formatTextPlayerNumber(turn), true);
			log.write("", true);
		}
		
	}

	/**
	 * Log a draw
	 */
	public void logDraw() {
		
		if(isLogging) {
			log.write("DRAW", true);
			log.write("", true);
		}
	}
	
	/**
	 * Log round number
	 */
	public void logRound() {
		if (isLogging) {
			log.write("", true);
			log.write("ROUND: " + rounds, true);
			log.write("", true);
		}
	}
	
}