package commandline;

import java.util.Random;

/**
 * Deck
 * ====
 * Manages all deck operations
 * A deck is a collection of Card objects
 * 
 * @author Team 12 - Paul McHard, Lewis Renfrew, Nick Ferrara, Kayleigh Chisholm & Eoghan Malone
 *
 */

public class Deck {
	
	private Card [] deckCards;
	
	/**
	 * Initialise a deck
	 */
	public Deck(int MAX_CARDS) { 
		
		deckCards = new Card[MAX_CARDS];
		
	}
	
	/**
	 * Initialise a deck from file
	 */
	public Deck(int MAX_CARDS, String file) { 
		
		deckCards = new Card[MAX_CARDS];
		
	}
	
	/**
	 * Shuffle main deck
	 */
	public Card [] shuffleDeck() {
		
		Random random = new Random();
		
		for(int i = deckCards.length - 1; i >  0; i--) {

			int index = random.nextInt(i+1);
			Card tempCard  = deckCards[index]; // preserve card
			deckCards[index] = deckCards[i]; // swap
			deckCards[i] = tempCard; // restore card
			
		}
		
		return deckCards;
						
	}

	/**
	 * Find next available index deck
	 * [the next NULL index closest to index 0]
	 * @return integer
	 */
	private int getNextIndex() {
		
		boolean found = false;
		int index = 0;
		
		while(!found) {
			
			if(deckCards[index]== null) {
				found = true;
			} else {
				index++;
			}

		}

		return index;
	}	

	/**
	 * Add a card to a deck
	 * @param c
	 * @param index
	 */
	public void addCardToDeck(Card c) {
	
		deckCards[getNextIndex()] = c;	

	}
	
	/**
	 * Get card object at index
	 * @param index
	 * @return Card object at index
	 */
	public Card getCardByIndex(int index) {
		
		return deckCards[index];
		
	}
		
	/**
	 * Count cards in deck
	 * @return number of cards in deck
	 */
	public int countCardsInDeck() {
		
		int counter = 0;
		
		for(int i = 0; i < deckCards.length;i++) {
		
			if(deckCards[i] != null) { counter++; }
		}
		
		return counter;
		
	}
	
}