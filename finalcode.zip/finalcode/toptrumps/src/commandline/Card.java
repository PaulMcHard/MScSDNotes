package commandline;

/**
 * Card Object
 * ===========
 * Manages card data and management
 * 
 * @author Team 12 - Paul McHard, Lewis Renfrew, Nick Ferrara, Kayleigh Chisholm & Eoghan Malone
 *
 */
public class Card {

	private final String cardDesc;
	private final int [] cardCategoryValues;

	/**
	 * Constructor 
	 * @param cardParams
	 * @param maxNoOfCategories
	 */
	public Card(String cardParams, int maxNoOfCategories) {
		
		String [] arrayData = cardParams.split(" "); // split line by spaces		
		cardCategoryValues = new int[maxNoOfCategories];
		cardDesc = arrayData[0]; // Card description at index 0

		for(int i = 0; i < maxNoOfCategories; i++) {
			
			// +1 to ignore description column i.e. we only need index 1 to 5, negating 0
			cardCategoryValues[i] = Integer.parseInt(arrayData[i+1]);
		
		}
		
	}
	
	/**
	 * Get card description
	 * @return description
	 */
	public String getCardDescription() {
		
		return this.cardDesc;
		
	}
	
	/**
	 * Get the card category values
	 * @return int []
	 */
	public int [] getCardValues() {
		
		return this.cardCategoryValues;
	}
	
	/**
	 * Get the strongest category
	 * [used for the computer player, see Assumptions]
	 * @return int
	 */
	public int getBestCategory() {
	
		int bestCat = -1; // first card will always be > -1
		int bestVal = -1;
		
		for(int i = 0; i < cardCategoryValues.length; i++) {
			
			// Doesn't matter if there are 2 or more categories of the same strength
			// This will ensure that an optimum card is played
			if(bestVal < cardCategoryValues[i]) { 
				bestVal = cardCategoryValues[i];
				bestCat = i;
			}
		}
		
		return bestCat;
	}
			
}