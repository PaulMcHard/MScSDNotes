package commandline;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Logging 
 * ========
 * - Takes care of writing data to log file
 * - Pays no regard to whether file exists, just creates new file.
 * 
 * @author Team 12 - Paul McHard, Lewis Renfrew, Nick Ferrara, Kayleigh Chisholm & Eoghan Malone
 *
 */
public class Log {

	private FileWriter writer; // Write handle
	private String file; // file to write to
	
	/**
	 * Constructor
	 * @param file
	 */
	public Log(String file) {
		
		this.file = file;
		open(); // open new file
		
	}
	
	/**
	 * Open file
	 */
	public void open() {
		
		try {

			writer = new FileWriter (file);		

		}
		
		catch (IOException e) {}
			
	}	
	
	/**
	 * Write to file
	 */
	public void write(String text,boolean newline) {
		
		try { 
			
			writer.write(text);
			if(newline) {
				writer.write("\n");
			}
			// flush the buffer, write now
			writer.flush();
			
		}
		
		catch (IOException e) {}
		
	}
	
	/**
	 * Close file
	 */
	public void closeFile() {
		
		try { 
			
			writer.close();
			
		}
		
		catch (IOException e) {}

	}
	
}