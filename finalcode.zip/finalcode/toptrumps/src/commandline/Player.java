package commandline;

/**
 * Player
 * ======
 * Manages player operations
 * 
 * @author Team 12 - Paul McHard, Lewis Renfrew, Nick Ferrara, Kayleigh Chisholm & Eoghan Malone
 *
 */
public class Player {
	
	private Card [] playerHand; // Array of cards
	private String playerType; // HUMAN or COMPUTER
	private int wins; // track wins for this player

	/**
	 * Constructor
	 * @param MAX_CARDS
	 */
	public Player(int MAX_CARDS) {
	
		playerHand = new Card[MAX_CARDS];
	
	}
	
	/**
	 * Get a deck of cards
	 * @return a deck of cards
	 */
	public Deck getDeck() {
		
		Deck deck = new Deck(playerHand.length);
		for(int i = 0; i < countCardsInDeck(); i++) {
			deck.addCardToDeck(this.playerHand[i]);
		}
		return deck;
	}
	
	/**
	 * Set the player hand
	 * Overwrite existing hand with temp deck
	 * [used after a win]
	 */
	public void setPlayerHand(Deck tempDeck, int MAX_CARDS) {
		
		for(int i = 0; i < MAX_CARDS; i++) {
			playerHand[i] = tempDeck.getCardByIndex(i);
		}
		
	}
	
	/**
	 * Set the player type [HUMAN or COMPUTER]
	 * @param playerType
	 */
	public void setPlayerType(String playerType) {
		
		this.playerType = playerType;
		
	}
	
	/**
	 * Find next available index in hand
	 * [the next NULL index closest to index 0]
	 * @return int
	 */
	private int getNextIndex() {
				
		boolean found = false;
		int index = 0;
		
		while(!found) {
			
			if(playerHand[index]== null) {
				found = true;
			} else {
				index++;
			}

		}

		return index;
	}
	
	/**
	 * Get the top card in the hand
	 * Will always be 1 less than the next available [null] index
	 * @return Card
	 */
	public Card getTopCard() {
		
		return (getNextIndex() == 0) ? playerHand[getNextIndex()] : playerHand[getNextIndex() - 1];
		
	}
	
	/**
	 * Get card object at index
	 * @param index
	 * @return Card object at index
	 */
	public Card getCardByIndex(int index) {
		
		return playerHand[index];
		
	}
	
	/**
	 * Get the top card index
	 * Will always be 1 less than the next available [null] index
	 * @return the index of the top card
	 */
	public int getTopCardIndex() {
		
		return getNextIndex() - 1;
		
	}
	
	/**
	 * Get the player type
	 * @return playerType HUMAN or COMPUTER
	 */
	public String getPlayerType() {
		
		return playerType;
	}

	/**
	 * Get the number of wins player has had
	 * 
	 * @return number of wins
	 */
	
	public int getWins() {
		
		return wins;
}
	
	/**
	 * Add a card to player hand
	 * @param c
	 * @param index
	 */
	public void addCardToDeck(Card c) {
	
		playerHand[getNextIndex()] = c;	
	
	}

	/**
	 * Delete the top card
	 * Set the value at index to NULL
	 */
	public void deleteTopCard() {
		
		this.playerHand[getTopCardIndex()] = null;
		
	}
	
	/**
	 * Count cards in deck
	 * @return number of cards in deck
	 */
	public int countCardsInDeck() {
		
		int counter = 0;
		
		for(int i = 0; i < playerHand.length;i++) {
		
			if(playerHand[i] != null) { counter++; }
		}
		
		return counter;
		
	}
	
	/**
	 * Update this player's total wins
	 */
	public void updateWins() {
		
		this.wins = wins + 1;
		
	}
	
}