package commandline;

/**
 * Top Trumps Command Line Application
 * ===================================
 *
 * @author Team 12 - Paul McHard, Lewis Renfrew, Nick Ferrara, Kayleigh Chisholm & Eoghan Malone
 */
public class TopTrumpsCLIApplication {

	/**
	 * This main method is called by TopTrumps.java when the user specifies that they want to run in
	 * command line mode. The contents of args[0] is whether we should write game logs to a file.
 	 * @param args
	 */
	public static void main(String[] args) {

		// Game initiation constants
		final String fileDeck = "StarCitizenDeck.txt"; 
		final String fileLog = "toptrumps.log";
		 // FAQ States always 1 HUMAN and 4 COMPUTER players
		final int noOfOfPlayers = 5;
		
		// Initiate game
		Game game = new Game();	
		if (args[0].equalsIgnoreCase("true")) {	// Logging
			Log log = new Log(fileLog);
			game.isLogging(true);
			game.setLog(log);
		}		
		game.setDeckFile(fileDeck);
		game.initMainDeck();
		game.logDeckContents("Initial", game.getMainDeck());
		game.shuffleDeck(); 
		game.logDeckContents("Shuffled", game.getMainDeck());

		// Game state
		boolean gameIsOver = false; // is the game over
		boolean isPlaying = false; // are we playing a game?
		boolean userWantsToQuit = false; // flag to check whether the user wants to quit the application
			
		// Loop until user wants to quit, game is over or a stalemate
		while (!userWantsToQuit) {
			
			// Does the user want to play a game, see stats report or quit
			if(!isPlaying || gameIsOver) {
			
				int input = game.getGameOptions(); // recursive call
				if(input == -1) { // quit
					
					userWantsToQuit = true;
					isPlaying = false;
				
				} else if(input == 1) { // play game
					
					// A game has ended, re-shuffle
					if(gameIsOver) {game.shuffleDeck();};
					game.initPlayers(noOfOfPlayers); // set number of players
					game.setTurn(game.getFirstPlayer()); // who goes first
					game.dealCards(); // deal cards
					game.logPlayerDeckContents(); // write contents of players' decks to log
					
					// Reset flags
					isPlaying = true;
					gameIsOver = false;
					
				} else { // stats
				
					game.displayStats();
					isPlaying = false;
					
				}
				
			}
			
			// Main game logic
			if(isPlaying) {
				
				// Check the game state before a round
				if(game.isGameOver()) { // A player has all the cards
				
					game.displayWinner(); // Display winner to console
					game.logWinnerOfGame(); // Write winner to log file
					game.saveStats(); // Write stats to the database
					game.resetGameStats(); // Game data
					gameIsOver = true;
					
				} else if (game.isStalemate()) { // Stalemate  
					
					// [See assumptions]
					// SPEC: In the case of a stalemate where the entire
					// deck is in the communal, we just end the game 
					// and no further action is taken
					gameIsOver = true;

				} else { // Play a round
				
					game.updateRounds(); // Add 1 to rounds played
					game.displayRound(); // Display round
					game.logRound(); // Log round number
					game.displayCurrentPlayer(); // Who's turn is it?
					game.displayCard(game.getTurn(), true);	// Display the top card [based on turn]
					game.logCardsInPlay();// Write all players' top cards to log
					
					// HUMAN and COMPUTER select categories
					if(game.getPlayerType() == "HUMAN") { // HUMAN selects category
					
						int input = game.getHumanCategory(); // recursive call
						if(input == -1) { // Quit sentinel
							userWantsToQuit=true; 
							isPlaying = false;
						} 
						
					} else { // COMPUTER selects category
						
						game.setCategory(game.getNextCard().getBestCategory()); 
		
					}

					if(!userWantsToQuit) {
						

						game.displayCatSelected(); // Category selected
						game.displayPlayerScores(); // Display player scores
						game.logCategory(); // Write category to log file
					
						if(game.isDraw()) { // Do we have a draw ...
			
							game.displayDraw();
							game.logDraw(); // Write draw to log file
							game.addCardsToCommunalDeck(); // Add all top cards to communal deck
							game.logDeckContents("Communal", game.getCommunalDeck());
							game.updateDraws(); // Add 1 to draw count
			
						} else { // .. get winner
							
							game.displayRoundWinner(); // Display who won round
							game.displayCard(game.getWinner(), true); // Display winning card
							game.setTurn(game.getWinner()); // Set turn
							game.logWinnerOfRound(); // Write winner to log file
							game.updateWins(); // Update current player's score
							game.addCardsToWinner();// Winner gets losers' top cards and communal deck
							game.logPlayerDeckContents(); // Write player deck contents to log file
						
						}
						
					}

				} // end main game logic
				
			} // end is playing
			
		} // end while
		
		// Quit application
		if(userWantsToQuit) {
			System.out.println("Quitting program");
			System.exit(0); // close application
		} 

	}
	
}