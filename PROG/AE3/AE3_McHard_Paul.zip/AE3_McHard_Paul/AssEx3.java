/**
 * The main class
 */
public class AssEx3 {
	/**
	 * The main method
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		//create an instance of the GUI and make sure it is visible.
		SportsCentreGUI display = new SportsCentreGUI();
		display.setVisible(true);
	}
}
